// CSC 254
// M1T1
// Michael Pipkin II
// 08/16/2021

#include <iostream>
using namespace std;

int main()
{
  cout << "Michael Pipkin II" << endl;

  cout << "I am studying C++ & C# this semester!" << endl;

  cout << "I am a father of two beautiful little girls that I love very much! I am also a hardcore gamer. I have even built my own gaming pc." << endl;
}